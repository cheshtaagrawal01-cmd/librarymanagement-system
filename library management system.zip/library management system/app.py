from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "secretkey123"

# -------------------
# Admin Credentials
# -------------------
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

# -------------------
# User Credentials
# -------------------
USER_EMAIL = "user@gmail.com"
USER_PASSWORD = "user123"

# Dummy Book List (Later database se replace kar sakte hain)
BOOKS = ["Science Book", "Economics Book", "Fiction Book"]

# -------------------
# Default page → User Login
# -------------------
@app.route('/')
def index():
    return redirect(url_for('user_login'))

# -------------------
# User Login
# -------------------
@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    error = None

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if email == USER_EMAIL and password == USER_PASSWORD:
            session['user'] = email
            return redirect(url_for('transactions'))
        else:
            error = "Invalid Email or Password"

    return render_template("user_login.html", error=error)

# -------------------
# Admin Login
# -------------------
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    error = None

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin'] = username
            return redirect(url_for('admin_home'))
        else:
            error = "Invalid Username or Password"

    return render_template("login.html", error=error)

# -------------------
# Transactions Page
# -------------------
@app.route('/transactions')
def transactions():
    if 'user' not in session and 'admin' not in session:
        return redirect(url_for('user_login'))
    return render_template('transactions.html')

# -------------------
# Book Available (Search Feature Added)
# -------------------
@app.route('/book_available', methods=['GET', 'POST'])
def book_available():

    if 'user' not in session and 'admin' not in session:
        return redirect(url_for('user_login'))

    result = None

    if request.method == 'POST':
        book_name = request.form.get('book_name')

        if book_name in BOOKS:
            result = "✅ Book is Available"
        else:
            result = "❌ Book Not Available"

    return render_template('book_available.html', result=result)

# -------------------
# Admin Home
# -------------------
@app.route('/admin_home')
def admin_home():
    if 'admin' not in session:
        return redirect(url_for('admin_login'))
    return render_template('admin_home.html')

# -------------------
# Home Page
# -------------------
@app.route('/home')
def home_page():
    return render_template('home.html')

# -------------------
# Logout
# -------------------
@app.route('/logout')
def logout():

    session.pop('admin', None)
    session.pop('user', None)

    return redirect(url_for('user_login'))

# -------------------
# Run App
# -------------------
if __name__ == "__main__":
    app.run(debug=True)
